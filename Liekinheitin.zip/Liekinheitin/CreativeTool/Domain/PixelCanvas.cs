﻿using System.Windows.Media;

namespace Liekinheitin.CreativeTool.Domain
{
    /// <summary>
    /// État couleur courant de la grille, indexé par (col, row).
    /// Source de vérité pour le rendu et pour la construction des frames d'animation.
    /// </summary>
    public sealed class PixelCanvas
    {
        private readonly Color[,] _pixels;

        public int Columns { get; }
        public int Rows { get; }

        public PixelCanvas(int columns, int rows, Color? fill = null)
        {
            Columns = columns;
            Rows = rows;
            _pixels = new Color[columns, rows];
            Clear(fill ?? Colors.Black);
        }

        public Color GetPixel(int col, int row) => _pixels[col, row];

        public void SetPixel(int col, int row, Color color)
        {
            if (col < 0 || col >= Columns || row < 0 || row >= Rows) return;
            _pixels[col, row] = color;
        }

        public void Clear(Color color)
        {
            for (int c = 0; c < Columns; c++)
                for (int r = 0; r < Rows; r++)
                    _pixels[c, r] = color;
        }
    }
}