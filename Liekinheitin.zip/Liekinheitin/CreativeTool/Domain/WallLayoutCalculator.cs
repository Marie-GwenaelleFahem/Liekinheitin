﻿namespace Liekinheitin.CreativeTool.Domain
{
    /// <summary>
    /// Place les EntityId (triés croissant) sur la grille en serpentin par colonne :
    /// colonne 0 bas->haut, colonne 1 haut->bas, alternance. id le plus bas = (0,0) = bas-gauche.
    /// </summary>
    public static class WallLayoutCalculator
    {
        public static IReadOnlyList<(int Id, int Col, int Row)> Compute(
            IEnumerable<int> entityIds, int columns, int rows)
        {
            var ids = entityIds.OrderBy(id => id).ToList();
            int capacity = columns * rows;

            var result = new List<(int Id, int Col, int Row)>(Math.Min(ids.Count, capacity));

            for (int i = 0; i < ids.Count && i < capacity; i++)
            {
                int col = i / rows;
                int posInCol = i % rows;
                bool goingUp = col % 2 == 0;
                int row = goingUp ? posInCol : rows - 1 - posInCol;
                result.Add((ids[i], col, row));
            }

            return result;
        }
    }
}