﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Liekinheitin.CreativeTool.Domain;
using Liekinheitin.CreativeTool.Infrastructure;

namespace Liekinheitin.CreativeTool.Views
{
    public partial class PixelGridCanvasView : UserControl
    {
        private WallLayout _layout;
        private BrushTool _brush;
        private PixelGridRenderer _renderer;
        private bool _isPainting;

        public PixelGridCanvasView()
        {
            InitializeComponent();
        }

        public void Initialize(WallLayout layout, PixelCanvas canvas, BrushTool brush)
        {
            _layout = layout;
            _brush = brush;
            _renderer = new PixelGridRenderer(layout);
            _renderer.DrawAll(canvas);
            GridImage.Source = _renderer.Bitmap;
        }

        private void OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            _isPainting = true;
            PaintAtScreenPoint(e.GetPosition(GridImage));
        }

        private void OnMouseMove(object sender, MouseEventArgs e)
        {
            if (_isPainting && e.LeftButton == MouseButtonState.Pressed)
                PaintAtScreenPoint(e.GetPosition(GridImage));
        }

        private void PaintAtScreenPoint(Point p)
        {
            int col = (int)(p.X / GridImage.ActualWidth * _layout.Columns);
            int rowFromTop = (int)(p.Y / GridImage.ActualHeight * _layout.Rows);
            int row = _layout.Rows - 1 - rowFromTop;

            if (col < 0 || col >= _layout.Columns || row < 0 || row >= _layout.Rows) return;

            if (_brush.Paint(col, row))
                _renderer.DrawPixel(col, row, _brush.CurrentColor);
        }
    }
}