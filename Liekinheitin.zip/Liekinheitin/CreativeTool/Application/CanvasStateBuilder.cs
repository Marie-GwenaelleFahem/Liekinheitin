﻿using Liekinheitin.CreativeTool.Domain;
using Liekinheitin.Domain.Entities;

namespace Liekinheitin.CreativeTool.Application
{
    /// <summary>
    /// Construit la liste d'entités (format RoutingHost) à partir du canvas courant.
    /// </summary>
    public static class CanvasStateBuilder
    {
        public static List<Entity> Build(PixelCanvas canvas, WallLayout layout)
        {
            var entities = new List<Entity>();

            for (int c = 0; c < layout.Columns; c++)
            {
                for (int r = 0; r < layout.Rows; r++)
                {
                    int id = layout.GetEntityId(c, r);
                    if (id == -1) continue; // pas de LED physique ici

                    var color = canvas.GetPixel(c, r);
                    entities.Add(new Entity
                    {
                        Id = id,
                        Channels = new byte[] { color.R, color.G, color.B }
                    });
                }
            }

            return entities;
        }
    }
}