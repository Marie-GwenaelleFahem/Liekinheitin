﻿using System;
using System.Windows.Media;
using System.Windows.Threading;
using Liekinheitin.Application.Interfaces;
using Liekinheitin.CreativeTool.Application;
using Liekinheitin.CreativeTool.Domain;
using Liekinheitin.Domain.Entities;

namespace Liekinheitin.CreativeTool.ViewModels
{
    public sealed class MainViewModel : IDisposable
    {
        private readonly PixelCanvas _canvas;
        private readonly WallLayout _layout;
        private readonly IStatePublisher _publisher;
        private readonly DispatcherTimer _publishTimer;

        public BrushTool Brush { get; }
        public PixelCanvas Canvas => _canvas;
        public WallLayout Layout => _layout;
        public ColorPickerViewModel ColorPicker { get; }

        public MainViewModel(PixelCanvas canvas, WallLayout layout, BrushTool brush, IStatePublisher publisher)
        {
            _canvas = canvas;
            _layout = layout;
            _publisher = publisher;
            Brush = brush;
            ColorPicker = new ColorPickerViewModel(brush);

            // Envoi continu ~40Hz, quel que soit l'écoute côté RoutingHost.
            _publishTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(25) };
            _publishTimer.Tick += (_, _) => PublishCurrentState();
            _publishTimer.Start();
        }

        private void PublishCurrentState()
        {
            var entities = CanvasStateBuilder.Build(_canvas, _layout);
            _publisher.Publish(new State { Entities = entities });
        }

        public void Dispose() => _publishTimer.Stop();
    }
}