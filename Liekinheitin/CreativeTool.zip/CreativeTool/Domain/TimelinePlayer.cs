﻿using System;
using System.Windows.Threading;

namespace Liekinheitin.CreativeTool.Domain
{
    /// <summary>
    /// Lit une Timeline : à chaque tick, évalue toutes les pistes à l'instant courant et
    /// applique le résultat à SceneManager. L'affichage et l'envoi réseau suivent
    /// automatiquement (SceneManager modifie Display, qui est déjà branché sur les deux).
    /// La notification UI (TimeChanged, pour le scrubber) est volontairement plus rare que
    /// le tick d'animation lui-même : rebinder un Slider WPF à 40Hz coûte plus cher que le
    /// calcul de l'animation en elle-même.
    /// </summary>
    public sealed class TimelinePlayer : IDisposable
    {
        private readonly Timeline _timeline;
        private readonly SceneManager _scene;
        private readonly DispatcherTimer _timer;
        private const int TickIntervalMs = 25; // ~40Hz, cohérent avec le reste du pipeline
        private const int UiNotifyEveryNTicks = 3; // ~13Hz d'affichage du curseur

        private int _tickCount;

        public bool IsPlaying { get; private set; }
        public double CurrentTimeSeconds { get; private set; }
        public double DurationSeconds => _timeline.DurationSeconds;

        /// <summary>Déclenché à intervalle réduit pendant la lecture (et à chaque Seek) —
        /// pour rafraîchir un scrubber UI sans le rebinder à pleine fréquence.</summary>
        public event Action? TimeChanged;

        public TimelinePlayer(Timeline timeline, SceneManager scene)
        {
            _timeline = timeline;
            _scene = scene;
            _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(TickIntervalMs) };
            _timer.Tick += (_, _) => Tick();
        }

        public void Play()
        {
            if (DurationSeconds <= 0) return; // rien à jouer, aucune keyframe posée
            IsPlaying = true;
            _timer.Start();
        }

        public void Pause()
        {
            IsPlaying = false;
            _timer.Stop();
        }

        public void Stop()
        {
            Pause();
            SeekTo(0);
        }

        public void SeekTo(double timeSeconds)
        {
            CurrentTimeSeconds = Math.Max(0, timeSeconds);
            ApplyCurrentTime();
            TimeChanged?.Invoke(); // un Seek manuel doit toujours rafraîchir immédiatement
        }

        private void Tick()
        {
            CurrentTimeSeconds += TickIntervalMs / 1000.0;
            if (CurrentTimeSeconds >= DurationSeconds)
            {
                CurrentTimeSeconds = DurationSeconds;
                Pause();
            }

            ApplyCurrentTime(); // la forme, elle, bouge à pleine fréquence (40Hz), inchangé

            _tickCount++;
            if (_tickCount % UiNotifyEveryNTicks == 0 || !IsPlaying)
                TimeChanged?.Invoke(); // le slider/texte se rafraîchit moins souvent
        }

        private void ApplyCurrentTime()
        {
            foreach (var track in _timeline.Tracks)
            {
                var kf = track.Evaluate(CurrentTimeSeconds);
                if (kf is null) continue;

                _scene.ApplyShapeState(track.ShapeId, kf.X, kf.Y, kf.BaseWidth, kf.BaseHeight, kf.Scale, kf.Color);
            }
        }

        public void Dispose() => _timer.Stop();
    }
}