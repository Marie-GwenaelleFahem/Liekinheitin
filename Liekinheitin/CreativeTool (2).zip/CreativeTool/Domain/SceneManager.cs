﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

namespace Liekinheitin.CreativeTool.Domain
{
    /// <summary>
    /// Gère le calque libre (pinceau/colonne) et le calque des formes placées, et recompose
    /// le canvas final (Display) à chaque changement de l'un ou l'autre. Display est ce qui
    /// est réellement affiché et envoyé au matériel — Freehand n'est qu'une mémoire interne.
    /// </summary>
    public sealed class SceneManager
    {
        private readonly WallLayout _layout;
        private readonly PixelCanvas _freehand;
        private readonly PixelCanvas _display;
        private readonly List<PlacedShape> _shapes = new();

        public PixelCanvas Display => _display;
        public IReadOnlyList<PlacedShape> Shapes => _shapes;

        public SceneManager(WallLayout layout)
        {
            _layout = layout;
            _freehand = new PixelCanvas(layout.Columns, layout.Rows, Colors.Black);
            _display = new PixelCanvas(layout.Columns, layout.Rows, Colors.Black);
        }

        public void ClearFreehand(Color color)
        {
            _freehand.Clear(color);
            Recompose(); // une seule recomposition, pas une par case
        }

        // ----- Calque libre (pinceau / remplissage colonne) -----

        public bool PaintFreehand(int col, int row, Color color)
        {
            if (!_layout.HasLed(col, row)) return false;
            _freehand.SetPixel(col, row, color);
            Recompose();
            return true;
        }

        public void FillColumnFreehand(int col, Color color)
        {
            if (col < 0 || col >= _layout.Columns) return;
            for (int row = 0; row < _layout.Rows; row++)
                if (_layout.HasLed(col, row))
                    _freehand.SetPixel(col, row, color);
            Recompose();
        }

        // ----- Formes -----

        public PlacedShape AddShape(ShapeType type, int x, int y, int width, int height, Color color)
        {
            var shape = new PlacedShape { Type = type, BaseWidth = width, BaseHeight = height, Color = color };
            ClampToGrid(shape, x, y);
            _shapes.Add(shape);
            Recompose();
            return shape;
        }

        public void RemoveShape(Guid id)
        {
            _shapes.RemoveAll(s => s.Id == id);
            Recompose();
        }

        public void MoveShape(Guid id, int newX, int newY)
        {
            var shape = Find(id);
            if (shape is null) return;
            ClampToGrid(shape, newX, newY);
            Recompose();
        }

        public void ResizeShape(Guid id, int newBaseWidth, int newBaseHeight)
        {
            var shape = Find(id);
            if (shape is null) return;
            shape.BaseWidth = Math.Max(1, newBaseWidth);
            shape.BaseHeight = Math.Max(1, newBaseHeight);
            ClampToGrid(shape, shape.X, shape.Y);
            Recompose();
        }

        public void SetScale(Guid id, double scale)
        {
            var shape = Find(id);
            if (shape is null) return;
            shape.Scale = Math.Max(0.05, scale);
            ClampToGrid(shape, shape.X, shape.Y);
            Recompose();
        }

        public void SetColor(Guid id, Color color)
        {
            var shape = Find(id);
            if (shape is null) return;
            shape.Color = color;
            Recompose();
        }

        /// <summary>Renvoie la forme la plus au-dessus (dernière créée) couvrant cette case, ou null.</summary>
        public PlacedShape? HitTest(int col, int row)
        {
            for (int i = _shapes.Count - 1; i >= 0; i--)
            {
                var s = _shapes[i];
                if (ShapeRasterizer.Rasterize(s.Type, s.X, s.Y, s.ActualWidth, s.ActualHeight)
                    .Any(c => c.Col == col && c.Row == row))
                    return s;
            }
            return null;
        }

        private PlacedShape? Find(Guid id) => _shapes.FirstOrDefault(s => s.Id == id);

        /// <summary>
        /// Force la forme à tenir entièrement dans la grille : réduit d'abord l'échelle
        /// si la taille réelle dépasse les dimensions de la grille, puis recale la position.
        /// </summary>
        private void ClampToGrid(PlacedShape shape, int desiredX, int desiredY)
        {
            if (shape.ActualWidth > _layout.Columns)
                shape.Scale = _layout.Columns / (double)shape.BaseWidth;
            if (shape.ActualHeight > _layout.Rows)
                shape.Scale = Math.Min(shape.Scale, _layout.Rows / (double)shape.BaseHeight);

            int w = shape.ActualWidth;
            int h = shape.ActualHeight;

            shape.X = Math.Clamp(desiredX, 0, _layout.Columns - w);
            shape.Y = Math.Clamp(desiredY, 0, _layout.Rows - h);
        }

        /// <summary>
        /// Recompose entièrement Display à partir de Freehand + toutes les formes
        /// (dans l'ordre de création, les dernières par-dessus). Ne marque comme "changées"
        /// (dirty, pour l'envoi réseau) que les cases dont la couleur finale a réellement
        /// changé — indispensable pour ne pas casser l'envoi delta existant.
        /// </summary>
        private void Recompose()
        {
            for (int col = 0; col < _layout.Columns; col++)
            {
                for (int row = 0; row < _layout.Rows; row++)
                {
                    if (!_layout.HasLed(col, row)) continue;

                    Color final = _freehand.GetPixel(col, row);
                    foreach (var shape in _shapes)
                    {
                        if (col >= shape.X && col < shape.X + shape.ActualWidth &&
                            row >= shape.Y && row < shape.Y + shape.ActualHeight &&
                            ShapeRasterizer.Rasterize(shape.Type, shape.X, shape.Y, shape.ActualWidth, shape.ActualHeight)
                                .Any(c => c.Col == col && c.Row == row))
                        {
                            final = shape.Color;
                        }
                    }

                    if (_display.GetPixel(col, row) != final)
                        _display.SetPixel(col, row, final);
                }
            }
        }
    }
}