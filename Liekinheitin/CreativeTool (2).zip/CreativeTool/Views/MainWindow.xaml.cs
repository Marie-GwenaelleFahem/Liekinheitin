﻿using Liekinheitin.CreativeTool.ViewModels;
using System.Windows;

namespace Liekinheitin.CreativeTool
{
    public partial class MainWindow : Window
    {
        public ShapeInspectorViewModel ShapeInspector { get; }
        public MainWindow()
        {
            InitializeComponent();
            Loaded += OnLoaded;

        // dans le constructeur
        ShapeInspector = new ShapeInspectorViewModel(scene);
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            if (DataContext is ViewModels.MainViewModel vm)
            {
                GridView.Initialize(vm.Layout, vm.Scene, vm.Brush, () => vm.ColorPicker.CurrentColor);

                GridView.SelectionChanged += vm.ShapeInspector.Load;
                vm.ShapeInspector.ShapeModified += () => GridView.RefreshFromScene();
            }

            ColumnList.ColumnSelected += OnColumnSelected;
        }

        private void OnColumnSelected(int col)
        {
            if (DataContext is ViewModels.MainViewModel vm)
            {
                vm.FillColumn(col);
                GridView.RefreshFromScene();
            }
        }
    }
}